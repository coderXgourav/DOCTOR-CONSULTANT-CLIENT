import React, { useEffect, useState } from "react";
import Sidebar from "../../../components/Sidebar";
import Topbar from "../../../components/Topbar";
import axios from "axios";

const ViewPatient = () => {
  const [patients, setPatients] = useState([]);
  const [selectedPatientId, setSelectedPatientId] = useState(null);

  const token=localStorage.getItem('token')
   

  const fetchPatients = async () => {
    try {
      const response = await axios.get(`${import.meta.env.VITE_API_URL}/patient/get-patient`,{
        headers :{
          'Authorization': `Bearer ${token}`
        }
      }
    
    );
      setPatients(response.data.data);
    } catch (error) {
      console.error("Error fetching patients:", error);
    }
  };

  const handleDeletePatient = async () => {
    try {
      await axios.delete(`${import.meta.env.VITE_API_URL}/patient/delete-patient/${selectedPatientId}`,{
        headers :{
          'Authorization': `Bearer ${token}`
        }
      });
      setPatients((prev) => prev.filter((patient) => patient._id !== selectedPatientId));
      setSelectedPatientId(null);
    } catch (error) {
      console.error("Error deleting patient:", error);
    }
  };

  useEffect(() => {
    fetchPatients();
  }, []);

  return (
    <>
      <div className="page-wrapper">
        <Topbar />
        <div className="main-container">
          <Sidebar />
          <div className="app-container">
            <div className="app-hero-header d-flex align-items-center">
              <ol className="breadcrumb">
                <li className="breadcrumb-item">
                  <i className="ri-home-8-line lh-1 pe-3 me-3 border-end" />
                  <a href="/">Home</a>
                </li>
                <li className="breadcrumb-item text-primary" aria-current="page">
                  Patients List
                </li>
              </ol>
              <div className="ms-auto d-lg-flex d-none flex-row">
                <div className="d-flex flex-row gap-1 day-sorting">
                  <button className="btn btn-sm btn-primary">Today</button>
                  {/* Other buttons */}
                </div>
              </div>
            </div>
            <div className="app-body">
              <div className="row gx-3">
                <div className="col-sm-12">
                  <div className="card">
                    <div className="card-header d-flex align-items-center justify-content-between">
                      <h5 className="card-title">Patients List</h5>
                      <a href="/add-patient" className="btn btn-primary ms-auto">
                        Add Patient
                      </a>
                    </div>
                    <div className="card-body">
                      <div className="table-responsive">
                        <table className="table truncate m-0 align-middle">
                          <thead>
                            <tr>
                              <th>No.</th>
                              <th>Patient Name</th>
                              <th>Gender</th>
                              <th>Age</th>
                              <th>Blood Group</th>
                              <th>Treatment</th>
                              <th>Mobile</th>
                              <th>Email</th>
                              <th>Address</th>
                              <th>Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                            {patients?.map((patient, index) => (
                              <tr key={patient._id}>
                                <td>{index + 1}</td>
                                <td>
                                  <img
                                    src="/assets/images/patient.png"
                                    className="img-shadow img-2x rounded-5 me-1"
                                    alt="Patient"
                                  />
                                  {patient.first_name} {patient.last_name}
                                </td>
                                <td>
                                  <span className={`badge bg-info-subtle text-info`}>
                                    {patient.gender}
                                  </span>
                                </td>
                                <td>{patient.age}</td>
                                <td>{patient.blood_group}</td>
                                <td>{patient.treatment}</td>
                                <td>{patient.mobile}</td>
                                <td>{patient.email}</td>
                                <td>{patient.address}</td>
                                <td>
                                  <div className="d-inline-flex gap-1">
                                    <button
                                      className="btn btn-outline-danger btn-sm"
                                      data-bs-toggle="modal"
                                      data-bs-target="#delRow"
                                      onClick={() => setSelectedPatientId(patient._id)}
                                    >
                                      <i className="ri-delete-bin-line" />
                                    </button>
                                    <a
                                      href={`/edit-patient/${patient._id}`}
                                      className="btn btn-outline-success btn-sm"
                                    >
                                      <i className="ri-edit-box-line" />
                                    </a>
                                    <a
                                      href={`/patient-dashboard/${patient._id}`}
                                      className="btn btn-outline-info btn-sm"
                                    >
                                      <i className="ri-eye-line" />
                                    </a>
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      <div className="modal fade" id="delRow" tabIndex={-1}>
                        <div className="modal-dialog modal-sm">
                          <div className="modal-content">
                            <div className="modal-header">
                              <h5 className="modal-title">Confirm</h5>
                              <button type="button" className="btn-close" data-bs-dismiss="modal" />
                            </div>
                            <div className="modal-body">
                              Are you sure you want to delete the patient?
                            </div>
                            <div className="modal-footer">
                              <button className="btn btn-outline-secondary" data-bs-dismiss="modal">
                                No
                              </button>
                              <button
                                className="btn btn-danger"
                                data-bs-dismiss="modal"
                                onClick={handleDeletePatient}
                              >
                                Yes
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ViewPatient;



// import Sidebar from "../../../components/Sidebar";
// import Topbar from "../../../components/Topbar";

// const ViewPatient = () => {
//   return (
//     <>
//       <div className="page-wrapper">
//         {/* App header starts */}
//         <Topbar />
//         {/* App header ends */}
//         {/* Main container starts */}
//         <div className="main-container">
//           {/* Sidebar wrapper starts */}
//           <Sidebar />
//           {/* Sidebar wrapper ends */}
//           {/* App container starts */}
//           <div className="app-container">
//             {/* App hero header starts */}
//             <div className="app-hero-header d-flex align-items-center">
//               {/* Breadcrumb starts */}
//               <ol className="breadcrumb">
//                 <li className="breadcrumb-item">
//                   <i className="ri-home-8-line lh-1 pe-3 me-3 border-end" />
//                   <a href="index-2.html">Home</a>
//                 </li>
//                 <li
//                   className="breadcrumb-item text-primary"
//                   aria-current="page"
//                 >
//                   Patients List
//                 </li>
//               </ol>
//               {/* Breadcrumb ends */}
//               {/* Sales stats starts */}
//               <div className="ms-auto d-lg-flex d-none flex-row">
//                 <div className="d-flex flex-row gap-1 day-sorting">
//                   <button className="btn btn-sm btn-primary">Today</button>
//                   <button className="btn btn-sm">7d</button>
//                   <button className="btn btn-sm">2w</button>
//                   <button className="btn btn-sm">1m</button>
//                   <button className="btn btn-sm">3m</button>
//                   <button className="btn btn-sm">6m</button>
//                   <button className="btn btn-sm">1y</button>
//                 </div>
//               </div>
//               {/* Sales stats ends */}
//             </div>
//             {/* App Hero header ends */}
//             {/* App body starts */}
//             <div className="app-body">
//               {/* Row starts */}
//               <div className="row gx-3">
//                 <div className="col-sm-12">
//                   <div className="card">
//                     <div className="card-header d-flex align-items-center justify-content-between">
//                       <h5 className="card-title">Patients List</h5>
//                       <a
//                         href="add-patient.html"
//                         className="btn btn-primary ms-auto"
//                       >
//                         Add Patient
//                       </a>
//                     </div>
//                     <div className="card-body">
//                       {/* Table starts */}
//                       <div className="table-responsive">
//                         <table
//                           id="basicExample"
//                           className="table truncate m-0 align-middle"
//                         >
//                           <thead>
//                             <tr>
//                               <th>No.</th>
//                               <th>Patient Name</th>
//                               <th>Gender</th>
//                               <th>Age</th>
//                               <th>Blood Group</th>
//                               <th>Treatment</th>
//                               <th>Mobile</th>
//                               <th>Email</th>
//                               <th>Address</th>
//                               <th>Actions</th>
//                             </tr>
//                           </thead>
//                           <tbody>
//                             <tr>
//                               <td>#89990</td>
//                               <td>
//                                 <img
//                                   src="assets/images/patient.png"
//                                   className="img-shadow img-2x rounded-5 me-1"
//                                   alt="Medical Admin Template"
//                                 />
//                                 Allan Stuart
//                               </td>
//                               <td>
//                                 <span className="badge bg-info-subtle text-info">
//                                   Male
//                                 </span>
//                               </td>
//                               <td>67</td>
//                               <td>O+</td>
//                               <td>Diabetes</td>
//                               <td>0987654321</td>
//                               <td>test@testing.com</td>
//                               <td>377 McGlynn, Orchard</td>
//                               <td>
//                                 <div className="d-inline-flex gap-1">
//                                   <button
//                                     className="btn btn-outline-danger btn-sm"
//                                     data-bs-toggle="modal"
//                                     data-bs-target="#delRow"
//                                   >
//                                     <i className="ri-delete-bin-line" />
//                                   </button>
//                                   <a
//                                     href="edit-patient.html"
//                                     className="btn btn-outline-success btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="Edit Patient Details"
//                                   >
//                                     <i className="ri-edit-box-line" />
//                                   </a>
//                                   <a
//                                     href="patient-dashboard.html"
//                                     className="btn btn-outline-info btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="View Dashboard"
//                                   >
//                                     <i className="ri-eye-line" />
//                                   </a>
//                                 </div>
//                               </td>
//                             </tr>
//                             <tr>
//                               <td>#89992</td>
//                               <td>
//                                 <img
//                                   src="assets/images/patient1.png"
//                                   className="img-shadow img-2x rounded-5 me-1"
//                                   alt="Medical Admin Template"
//                                 />
//                                 Katie Robinson
//                               </td>
//                               <td>
//                                 <span className="badge bg-warning-subtle text-warning">
//                                   Female
//                                 </span>
//                               </td>
//                               <td>33</td>
//                               <td>B+</td>
//                               <td>Pediatric</td>
//                               <td>0987654321</td>
//                               <td>test@testing.com</td>
//                               <td>229 Hills Courts, Doyleland</td>
//                               <td>
//                                 <div className="d-inline-flex gap-1">
//                                   <button
//                                     className="btn btn-outline-danger btn-sm"
//                                     data-bs-toggle="modal"
//                                     data-bs-target="#delRow"
//                                   >
//                                     <i className="ri-delete-bin-line" />
//                                   </button>
//                                   <a
//                                     href="edit-patient.html"
//                                     className="btn btn-outline-success btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="Edit Patient Details"
//                                   >
//                                     <i className="ri-edit-box-line" />
//                                   </a>
//                                   <a
//                                     href="patient-dashboard.html"
//                                     className="btn btn-outline-info btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="View Dashboard"
//                                   >
//                                     <i className="ri-eye-line" />
//                                   </a>
//                                 </div>
//                               </td>
//                             </tr>
//                             <tr>
//                               <td>#89995</td>
//                               <td>
//                                 <img
//                                   src="assets/images/patient2.png"
//                                   className="img-shadow img-2x rounded-5 me-1"
//                                   alt="Medical Admin Template"
//                                 />
//                                 Pam Higgins
//                               </td>
//                               <td>
//                                 <span className="badge bg-info-subtle text-info">
//                                   Male
//                                 </span>
//                               </td>
//                               <td>28</td>
//                               <td>AB+</td>
//                               <td>Asthma</td>
//                               <td>0987654321</td>
//                               <td>test@testing.com</td>
//                               <td>59 Graham Fall, Nickville</td>
//                               <td>
//                                 <div className="d-inline-flex gap-1">
//                                   <button
//                                     className="btn btn-outline-danger btn-sm"
//                                     data-bs-toggle="modal"
//                                     data-bs-target="#delRow"
//                                   >
//                                     <i className="ri-delete-bin-line" />
//                                   </button>
//                                   <a
//                                     href="edit-patient.html"
//                                     className="btn btn-outline-success btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="Edit Patient Details"
//                                   >
//                                     <i className="ri-edit-box-line" />
//                                   </a>
//                                   <a
//                                     href="patient-dashboard.html"
//                                     className="btn btn-outline-info btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="View Dashboard"
//                                   >
//                                     <i className="ri-eye-line" />
//                                   </a>
//                                 </div>
//                               </td>
//                             </tr>
//                             <tr>
//                               <td>#89345</td>
//                               <td>
//                                 <img
//                                   src="assets/images/patient3.png"
//                                   className="img-shadow img-2x rounded-5 me-1"
//                                   alt="Medical Admin Template"
//                                 />
//                                 Ashley Clay
//                               </td>
//                               <td>
//                                 <span className="badge bg-info-subtle text-info">
//                                   Male
//                                 </span>
//                               </td>
//                               <td>77</td>
//                               <td>A+</td>
//                               <td>Chancroid</td>
//                               <td>0987654321</td>
//                               <td>test@testing.com</td>
//                               <td>491 Towne Parkway</td>
//                               <td>
//                                 <div className="d-inline-flex gap-1">
//                                   <button
//                                     className="btn btn-outline-danger btn-sm"
//                                     data-bs-toggle="modal"
//                                     data-bs-target="#delRow"
//                                   >
//                                     <i className="ri-delete-bin-line" />
//                                   </button>
//                                   <a
//                                     href="edit-patient.html"
//                                     className="btn btn-outline-success btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="Edit Patient Details"
//                                   >
//                                     <i className="ri-edit-box-line" />
//                                   </a>
//                                   <a
//                                     href="patient-dashboard.html"
//                                     className="btn btn-outline-info btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="View Dashboard"
//                                   >
//                                     <i className="ri-eye-line" />
//                                   </a>
//                                 </div>
//                               </td>
//                             </tr>
//                             <tr>
//                               <td>#87690</td>
//                               <td>
//                                 <img
//                                   src="assets/images/patient4.png"
//                                   className="img-shadow img-2x rounded-5 me-1"
//                                   alt="Medical Admin Template"
//                                 />
//                                 Keith Coleman
//                               </td>
//                               <td>
//                                 <span className="badge bg-warning-subtle text-warning">
//                                   Female
//                                 </span>
//                               </td>
//                               <td>49</td>
//                               <td>O+</td>
//                               <td>Diphtheria</td>
//                               <td>0987654321</td>
//                               <td>test@testing.com</td>
//                               <td>289 Markus Turnpike</td>
//                               <td>
//                                 <div className="d-inline-flex gap-1">
//                                   <button
//                                     className="btn btn-outline-danger btn-sm"
//                                     data-bs-toggle="modal"
//                                     data-bs-target="#delRow"
//                                   >
//                                     <i className="ri-delete-bin-line" />
//                                   </button>
//                                   <a
//                                     href="edit-patient.html"
//                                     className="btn btn-outline-success btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="Edit Patient Details"
//                                   >
//                                     <i className="ri-edit-box-line" />
//                                   </a>
//                                   <a
//                                     href="patient-dashboard.html"
//                                     className="btn btn-outline-info btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="View Dashboard"
//                                   >
//                                     <i className="ri-eye-line" />
//                                   </a>
//                                 </div>
//                               </td>
//                             </tr>
//                             <tr>
//                               <td>#82894</td>
//                               <td>
//                                 <img
//                                   src="assets/images/patient5.png"
//                                   className="img-shadow img-2x rounded-5 me-1"
//                                   alt="Medical Admin Template"
//                                 />
//                                 Nick Morrow
//                               </td>
//                               <td>
//                                 <span className="badge bg-info-subtle text-info">
//                                   Male
//                                 </span>
//                               </td>
//                               <td>69</td>
//                               <td>A+</td>
//                               <td>Thyroid</td>
//                               <td>0987654321</td>
//                               <td>test@testing.com</td>
//                               <td>835 Lorena Stream</td>
//                               <td>
//                                 <div className="d-inline-flex gap-1">
//                                   <button
//                                     className="btn btn-outline-danger btn-sm"
//                                     data-bs-toggle="modal"
//                                     data-bs-target="#delRow"
//                                   >
//                                     <i className="ri-delete-bin-line" />
//                                   </button>
//                                   <a
//                                     href="edit-patient.html"
//                                     className="btn btn-outline-success btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="Edit Patient Details"
//                                   >
//                                     <i className="ri-edit-box-line" />
//                                   </a>
//                                   <a
//                                     href="patient-dashboard.html"
//                                     className="btn btn-outline-info btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="View Dashboard"
//                                   >
//                                     <i className="ri-eye-line" />
//                                   </a>
//                                 </div>
//                               </td>
//                             </tr>
//                             <tr>
//                               <td>#80762</td>
//                               <td>
//                                 <img
//                                   src="assets/images/patient4.png"
//                                   className="img-shadow img-2x rounded-5 me-1"
//                                   alt="Medical Admin Template"
//                                 />
//                                 Wendi Combs
//                               </td>
//                               <td>
//                                 <span className="badge bg-warning-subtle text-warning">
//                                   Female
//                                 </span>
//                               </td>
//                               <td>28</td>
//                               <td>AB+</td>
//                               <td>Cyclospora</td>
//                               <td>0987654321</td>
//                               <td>test@testing.com</td>
//                               <td>360 Branden Knoll</td>
//                               <td>
//                                 <div className="d-inline-flex gap-1">
//                                   <button
//                                     className="btn btn-outline-danger btn-sm"
//                                     data-bs-toggle="modal"
//                                     data-bs-target="#delRow"
//                                   >
//                                     <i className="ri-delete-bin-line" />
//                                   </button>
//                                   <a
//                                     href="edit-patient.html"
//                                     className="btn btn-outline-success btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="Edit Patient Details"
//                                   >
//                                     <i className="ri-edit-box-line" />
//                                   </a>
//                                   <a
//                                     href="patient-dashboard.html"
//                                     className="btn btn-outline-info btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="View Dashboard"
//                                   >
//                                     <i className="ri-eye-line" />
//                                   </a>
//                                 </div>
//                               </td>
//                             </tr>
//                             <tr>
//                               <td>#83308</td>
//                               <td>
//                                 <img
//                                   src="assets/images/patient1.png"
//                                   className="img-shadow img-2x rounded-5 me-1"
//                                   alt="Medical Admin Template"
//                                 />
//                                 Carole Dodson
//                               </td>
//                               <td>
//                                 <span className="badge bg-warning-subtle text-warning">
//                                   Female
//                                 </span>
//                               </td>
//                               <td>95</td>
//                               <td>A+</td>
//                               <td>Conjunctivitis</td>
//                               <td>0987654321</td>
//                               <td>test@testing.com</td>
//                               <td>Suite 510 Kiana Track</td>
//                               <td>
//                                 <div className="d-inline-flex gap-1">
//                                   <button
//                                     className="btn btn-outline-danger btn-sm"
//                                     data-bs-toggle="modal"
//                                     data-bs-target="#delRow"
//                                   >
//                                     <i className="ri-delete-bin-line" />
//                                   </button>
//                                   <a
//                                     href="edit-patient.html"
//                                     className="btn btn-outline-success btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="Edit Patient Details"
//                                   >
//                                     <i className="ri-edit-box-line" />
//                                   </a>
//                                   <a
//                                     href="patient-dashboard.html"
//                                     className="btn btn-outline-info btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="View Dashboard"
//                                   >
//                                     <i className="ri-eye-line" />
//                                   </a>
//                                 </div>
//                               </td>
//                             </tr>
//                             <tr>
//                               <td>#83306</td>
//                               <td>
//                                 <img
//                                   src="assets/images/patient.png"
//                                   className="img-shadow img-2x rounded-5 me-1"
//                                   alt="Medical Admin Template"
//                                 />
//                                 Juan Meyers
//                               </td>
//                               <td>
//                                 <span className="badge bg-info-subtle text-info">
//                                   Male
//                                 </span>
//                               </td>
//                               <td>55</td>
//                               <td>B+</td>
//                               <td>Diabetes</td>
//                               <td>0987654321</td>
//                               <td>test@testing.com</td>
//                               <td>6921 Geoffrey Spur</td>
//                               <td>
//                                 <div className="d-inline-flex gap-1">
//                                   <button
//                                     className="btn btn-outline-danger btn-sm"
//                                     data-bs-toggle="modal"
//                                     data-bs-target="#delRow"
//                                   >
//                                     <i className="ri-delete-bin-line" />
//                                   </button>
//                                   <a
//                                     href="edit-patient.html"
//                                     className="btn btn-outline-success btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="Edit Patient Details"
//                                   >
//                                     <i className="ri-edit-box-line" />
//                                   </a>
//                                   <a
//                                     href="patient-dashboard.html"
//                                     className="btn btn-outline-info btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="View Dashboard"
//                                   >
//                                     <i className="ri-eye-line" />
//                                   </a>
//                                 </div>
//                               </td>
//                             </tr>
//                             <tr>
//                               <td>#86345</td>
//                               <td>
//                                 <img
//                                   src="assets/images/patient5.png"
//                                   className="img-shadow img-2x rounded-5 me-1"
//                                   alt="Medical Admin Template"
//                                 />
//                                 Naomi Dawson
//                               </td>
//                               <td>
//                                 <span className="badge bg-info-subtle text-info">
//                                   Male
//                                 </span>
//                               </td>
//                               <td>32</td>
//                               <td>AB+</td>
//                               <td>Celiac</td>
//                               <td>0987654321</td>
//                               <td>test@testing.com</td>
//                               <td>352 Raynor Junction</td>
//                               <td>
//                                 <div className="d-inline-flex gap-1">
//                                   <button
//                                     className="btn btn-outline-danger btn-sm"
//                                     data-bs-toggle="modal"
//                                     data-bs-target="#delRow"
//                                   >
//                                     <i className="ri-delete-bin-line" />
//                                   </button>
//                                   <a
//                                     href="edit-patient.html"
//                                     className="btn btn-outline-success btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="Edit Patient Details"
//                                   >
//                                     <i className="ri-edit-box-line" />
//                                   </a>
//                                   <a
//                                     href="patient-dashboard.html"
//                                     className="btn btn-outline-info btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="View Dashboard"
//                                   >
//                                     <i className="ri-eye-line" />
//                                   </a>
//                                 </div>
//                               </td>
//                             </tr>
//                             <tr>
//                               <td>#83349</td>
//                               <td>
//                                 <img
//                                   src="assets/images/patient2.png"
//                                   className="img-shadow img-2x rounded-5 me-1"
//                                   alt="Medical Admin Template"
//                                 />
//                                 Emmitt Macias
//                               </td>
//                               <td>
//                                 <span className="badge bg-info-subtle text-info">
//                                   Male
//                                 </span>
//                               </td>
//                               <td>93</td>
//                               <td>A+</td>
//                               <td>Cervical</td>
//                               <td>0987654321</td>
//                               <td>test@testing.com</td>
//                               <td>834 Quitzon Dale Connie</td>
//                               <td>
//                                 <div className="d-inline-flex gap-1">
//                                   <button
//                                     className="btn btn-outline-danger btn-sm"
//                                     data-bs-toggle="modal"
//                                     data-bs-target="#delRow"
//                                   >
//                                     <i className="ri-delete-bin-line" />
//                                   </button>
//                                   <a
//                                     href="edit-patient.html"
//                                     className="btn btn-outline-success btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="Edit Patient Details"
//                                   >
//                                     <i className="ri-edit-box-line" />
//                                   </a>
//                                   <a
//                                     href="patient-dashboard.html"
//                                     className="btn btn-outline-info btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="View Dashboard"
//                                   >
//                                     <i className="ri-eye-line" />
//                                   </a>
//                                 </div>
//                               </td>
//                             </tr>
//                             <tr>
//                               <td>#82348</td>
//                               <td>
//                                 <img
//                                   src="assets/images/patient4.png"
//                                   className="img-shadow img-2x rounded-5 me-1"
//                                   alt="Medical Admin Template"
//                                 />
//                                 Reba Fisher
//                               </td>
//                               <td>
//                                 <span className="badge bg-warning-subtle text-warning">
//                                   Female
//                                 </span>
//                               </td>
//                               <td>59</td>
//                               <td>A+</td>
//                               <td>Alphaviruses</td>
//                               <td>0987654321</td>
//                               <td>test@testing.com</td>
//                               <td>806 Je Alley, Robelfurt</td>
//                               <td>
//                                 <div className="d-inline-flex gap-1">
//                                   <button
//                                     className="btn btn-outline-danger btn-sm"
//                                     data-bs-toggle="modal"
//                                     data-bs-target="#delRow"
//                                   >
//                                     <i className="ri-delete-bin-line" />
//                                   </button>
//                                   <a
//                                     href="edit-patient.html"
//                                     className="btn btn-outline-success btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="Edit Patient Details"
//                                   >
//                                     <i className="ri-edit-box-line" />
//                                   </a>
//                                   <a
//                                     href="patient-dashboard.html"
//                                     className="btn btn-outline-info btn-sm"
//                                     data-bs-toggle="tooltip"
//                                     data-bs-placement="top"
//                                     data-bs-title="View Dashboard"
//                                   >
//                                     <i className="ri-eye-line" />
//                                   </a>
//                                 </div>
//                               </td>
//                             </tr>
//                           </tbody>
//                         </table>
//                       </div>
//                       {/* Table ends */}
//                       {/* Modal Delete Row */}
//                       <div
//                         className="modal fade"
//                         id="delRow"
//                         tabIndex={-1}
//                         aria-labelledby="delRowLabel"
//                         aria-hidden="true"
//                       >
//                         <div className="modal-dialog modal-sm">
//                           <div className="modal-content">
//                             <div className="modal-header">
//                               <h5 className="modal-title" id="delRowLabel">
//                                 Confirm
//                               </h5>
//                               <button
//                                 type="button"
//                                 className="btn-close"
//                                 data-bs-dismiss="modal"
//                                 aria-label="Close"
//                               />
//                             </div>
//                             <div className="modal-body">
//                               Are you sure you want to delete the patient?
//                             </div>
//                             <div className="modal-footer">
//                               <div className="d-flex justify-content-end gap-2">
//                                 <button
//                                   className="btn btn-outline-secondary"
//                                   data-bs-dismiss="modal"
//                                   aria-label="Close"
//                                 >
//                                   No
//                                 </button>
//                                 <button
//                                   className="btn btn-danger"
//                                   data-bs-dismiss="modal"
//                                   aria-label="Close"
//                                 >
//                                   Yes
//                                 </button>
//                               </div>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//               {/* Row ends */}
//             </div>
//             {/* App body ends */}
//             {/* App footer starts */}

//             {/* App footer ends */}
//           </div>
//           {/* App container ends */}
//         </div>
//         {/* Main container ends */}
//       </div>
//     </>
//   );
// };

// export default ViewPatient;
